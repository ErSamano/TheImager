package com.parser.interfaces;

import java.io.File;
import com.parser.beans.ProcessedImages;

public interface IImageNameProcessor {

	public  ProcessedImages process(File fileFolder ,String group,String tag) throws Exception;
	
}
