package com.parser.processors;

import java.io.File;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.parser.beans.ImageHierarchy;
import com.parser.beans.ProcessedImages;
import com.parser.interfaces.IImageNameProcessor;

public class ImageNameParser implements IImageNameProcessor {
	
	private static final String PHOTO_PATTERN = "([A-Za-z]+)-(\\d\\d\\d\\d)-(\\d)-([A-Z])(\\.[A-Za-z]+)";
	private Pattern photoPattern = Pattern.compile(PHOTO_PATTERN);
	
	private static final String IMAGE_PATTERN = "sg(\\d\\d\\d\\d)A[-|\\+](\\d\\d\\.\\d\\d)[A-Z][-|\\+](\\d\\d)-([A-Za-z]+)(\\.[a-z]+)";
	private Pattern imagePattern = Pattern.compile(IMAGE_PATTERN);
	
	public ImageNameParser()
	{
	}
	
	
	private ImageHierarchy extractType1Info(File imageFile,String tag,String group) throws Exception {
		
		if (imageFile!=null && imageFile.isFile()) {
			Matcher m = imagePattern.matcher(imageFile.getName());
			if (m.find()) {
				
				/*    m.group(1) - SubGroup
				 	  m.group(2) - ValueA
					  m.group(3) - ValueB
				      m.group(4) - SubType	
				 */
				ImageHierarchy imageData = new ImageHierarchy(imageFile.getName(), imageFile.getAbsolutePath(), m.group(1), tag, group);
				imageData.addImageParameters(m.group(2), m.group(3),m.group(4), null, null);
				return imageData;
				
			} else {
				return null;
			}

		} else {
			return null;
		}
	}
	
	private ImageHierarchy extractType2Info(File imageFile,String tag,String group) {

		if (imageFile!=null && imageFile.isFile()) {

			Matcher patternMatcher = photoPattern.matcher(imageFile.getName());

			if (patternMatcher.find()) {
				/*
				     patternMatcher.group(1) - Group
				     patternMatcher.group(2) - SubGroup
				     patternMatcher.group(3) - SequenceNumber
				     patternMatcher.group(4) - PhotoAtribute
				 */
				
				ImageHierarchy imageData = new ImageHierarchy(imageFile.getName(), imageFile.getAbsolutePath(), patternMatcher.group(2), tag, patternMatcher.group(1));
				imageData.addImageParameters(null, null,null, patternMatcher.group(3), patternMatcher.group(4));
				return imageData;
			} 
		} 
		return null;
	}
	
	private File[] getFiles(File folder ,String group,String tag){
		
		ArrayList<File> fileList= new ArrayList<File>();
		
		if(folder!=null)
		{
			ArrayList<File> directories = new ArrayList<File>();
			directories.add(folder);
			
			while(!directories.isEmpty() && (folder = directories.remove(0))!=null)
			{
				File[] listOfFiles = folder.listFiles();
				if(listOfFiles!=null)
				{
					for ( File file : listOfFiles) {
						if(file.isFile()){

							if((group!=null && file.getName().contains(group)) || (tag!=null && file.getName().contains(tag))){
								System.out.println(file.getName());
								fileList.add(file);
							}

						}else if(file.isDirectory()){
							directories.add(file);					 
						}
					}
				}
				
			}
		}
		return fileList.toArray(new File[]{});
		
	}
	
	public ProcessedImages process(File folder ,String group,String tag) throws Exception{
		
		ImageHierarchy imageInfo = null;

		ProcessedImages collection = new ProcessedImages();
		File[] imageFiles = getFiles(folder, group, tag);
		for (File imageFile : imageFiles) {
			imageInfo = extractType1Info(imageFile, tag, group);
			if(imageInfo!=null)
			{
				collection.AddImage(imageInfo);
			}
			else
			{
				imageInfo = extractType2Info(imageFile,tag, group);
				if(imageInfo!=null)
				{
					collection.AddImage(imageInfo);
				}
			}
				
		}
		return collection;
	}


}
