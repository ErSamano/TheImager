package com.parser.beans;

public class ImageParameters {

	private String valueA  = "-";
	private String valueB  = "-";
	private String subType = "-"; 
	
	private String sequenceNumber  = "-";
	private String photoAttribute  = "-";
	
	public String getValueA() {
		return valueA;
	}
	
	public void setValueA(String valueA) {
		if(valueA!=null && !valueA.trim().isEmpty())
			this.valueA = valueA;
		else
			valueA = "-";
	}
	
	public String getValueB() {
		return valueB;
	}
	
	public void setValueB(String valueB) {
		if(valueB!=null && !valueB.trim().isEmpty())
			this.valueB = valueB;
		else
			valueB = "-";
	}
	
	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		if(subType!=null && !subType.trim().isEmpty())
			this.subType = subType;
		else
			subType = "-";
	}
	
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	
	public void setSequenceNumber(String sequenceNumber) {
		if(sequenceNumber!=null && !sequenceNumber.trim().isEmpty())
			this.sequenceNumber = sequenceNumber;
		else
			sequenceNumber = "-";
	}
	
	public String getPhotoAttribute() {
		return photoAttribute;
	}
	
	public void setPhotoAttribute(String photoAttribute) {
		if(photoAttribute!=null && !photoAttribute.trim().isEmpty())
			this.photoAttribute = photoAttribute;
		else
			photoAttribute = "-";
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Value A : "+ valueA +"\n");
		sb.append("Value B : "+ valueB +"\n");
		sb.append("SubType : "+ subType +"\n");
		sb.append("SequenceNumber : "+ sequenceNumber +"\n");
		sb.append("PhotoAtribute : "+ photoAttribute );
		return sb.toString();
	}

}
