package com.parser.beans;

public class ImageHierarchy {

	private String fileName = null;
	private String path = null;
	private String tag = null;
	private String group = null;
	private ImageParameters imageParameters = null;
	private ImageSubGroup subGroup = null;
	
	public ImageHierarchy(String fileName, String path, String subGroup, String tag, String group) {
		super();
		this.fileName = fileName;
		this.path = path;
		this.subGroup = new ImageSubGroup(subGroup);
		this.tag = tag;
		this.group = group;
	}
	
	public void addImageParameters(String valueA, String valueB,String subType,String sequenceNumber, String photoAttribute)
	{
		 imageParameters = new ImageParameters();
		 imageParameters.setValueA(valueA);
		 imageParameters.setValueB(valueB);
		 imageParameters.setSubType(subType);
		 imageParameters.setSequenceNumber(sequenceNumber);
		 imageParameters.setPhotoAttribute(photoAttribute);
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public ImageParameters getImageParameters() {
		return imageParameters;
	}

	public void setImageParameters(ImageParameters imageParameters) {
		this.imageParameters = imageParameters;
	}

	public ImageSubGroup getSubGroup() {
		return subGroup;
	}

	public void setSubGroup(ImageSubGroup subGroup) {
		this.subGroup = subGroup;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("----- FileName : " + fileName+" -----\n");
		sb.append("Tag : "+ tag +"\n");
		sb.append("Group : "+ group +"\n");
		sb.append("SubGroup : "+ subGroup +"\n");
		sb.append("Path : "+ path +"\n");
		sb.append("ImageParameters :\n"+ imageParameters);
		sb.append("\n-------------------------------------\n");
		return sb.toString();
	}
}
