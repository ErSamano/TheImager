package com.parser.beans;

public class ImageSubGroup {

	private String subGroup = "-";

	public ImageSubGroup(String subGroup) {
		super();
		this.subGroup = subGroup;
	}

	public String getSubGroup() {
		return subGroup;
	}

	public void setSubGroup(String subGroup) {
		if(subGroup!=null && !subGroup.trim().isEmpty())
			this.subGroup = subGroup;
		else
			this.subGroup = "-";
	}
	
	public String toString()
	{
		return subGroup;
	}
}
