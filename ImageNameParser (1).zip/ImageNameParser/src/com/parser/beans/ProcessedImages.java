package com.parser.beans;

import java.util.ArrayList;
import java.util.List;

public class ProcessedImages {
	
	List<ImageHierarchy> data = new ArrayList<ImageHierarchy>();

	public List<ImageHierarchy> getData() {
		return data;
	}

	public void AddImage(ImageHierarchy imageInfo) {
		data.add(imageInfo);
	}
	
	public boolean hasData()
	{
		return !(data.isEmpty());
	}
	
	
}
