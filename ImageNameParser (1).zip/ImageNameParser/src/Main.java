import java.io.File;

import com.parser.beans.ImageHierarchy;
import com.parser.beans.ProcessedImages;
import com.parser.interfaces.IImageNameProcessor;
import com.parser.processors.ImageNameParser;


public class Main  {

	public static void main(String[] args) throws Exception {

		String group = "exterior";
		String tag  = "Photo";
		File generalPath = new File("C:/resources_files");
		
		IImageNameProcessor imageNameProcessor = new ImageNameParser() ;
		ProcessedImages processedData=imageNameProcessor.process(generalPath,group,tag);
		
		if(processedData.hasData())
		{
			System.out.println("\n====== Images Information ===========\n");
			for(ImageHierarchy data: processedData.getData())
					System.out.println(data.toString());

		}
		
	}

}
